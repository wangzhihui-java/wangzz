package Vis;

public interface IProduct {
void accept(AVisitor visitor);
}
