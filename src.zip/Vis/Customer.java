package Vis;

public class Customer extends AVisitor {

	public void visit(Apple apple) {
		// TODO Auto-generated method stub
System.out.println("�˿�"+name+"ѡƻ��");
	}

	public void visit(Book book) {
		// TODO Auto-generated method stub
		System.out.println("�˿�"+name+"����");
	}

}
