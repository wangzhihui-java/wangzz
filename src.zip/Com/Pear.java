package Com;

public class Pear extends MyElement {


	@Override
	public void eat() {
		// TODO Auto-generated method stub
		System.out.println("������");
	}

}
