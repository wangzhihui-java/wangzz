package pro;

public class Apple extends Myfruit {
public Apple()
{
	kind="Apple";}
}
