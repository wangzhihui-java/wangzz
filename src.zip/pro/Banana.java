package pro;

public class Banana extends Myfruit{
	public Banana()
	{
		kind="Banana";
	}

}
