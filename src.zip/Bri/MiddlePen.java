package Bri;

public class MiddlePen extends Pen {



	@Override
	public void draw(String name) {
		// TODO Auto-generated method stub
		String penType="�к�ë�ʻ���";
        this.color.bepaint(penType, name);
	}

}
