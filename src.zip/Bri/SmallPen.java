package Bri;

public class SmallPen extends Pen {

	public void draw(String name) {
		// TODO Auto-generated method stub
		String penType="С��ë�ʻ���";
        this.color.bepaint(penType, name);
	}
}
