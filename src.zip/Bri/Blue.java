package Bri;



public class Blue implements Color {

	@Override
	public void bepaint(String penType, String name) {
		// TODO Auto-generated method stub
		System.out.println(penType+"��ɫ��"+name);
	}

}
