package DProxy;

public interface IShowPic {
void ShowPic(String picname);
}
