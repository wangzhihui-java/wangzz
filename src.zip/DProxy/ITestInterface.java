package DProxy;

public interface ITestInterface {
public void  SendMessage(String mes);
}
