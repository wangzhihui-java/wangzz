package Fac;

public class AirConditioner {
public void on()
{
System.out.println("�յ��򿪣�");	
}
public void off()
{
System.out.println("�յ��رգ�");	
}
}
