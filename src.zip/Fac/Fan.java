package Fac;

public class Fan {
	public void on()
	{
	System.out.println("Fan�򿪣�");	
	}
	public void off()
	{
	System.out.println("Fan�رգ�");	
	}
	}
