package Fac;

public class Televison {
	public void on()
	{
	System.out.println("���Ӵ򿪣�");	
	}
	public void off()
	{
	System.out.println("���ӹرգ�");	
	}
	}
