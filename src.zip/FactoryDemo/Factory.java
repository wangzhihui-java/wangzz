package FactoryDemo;

public class Factory {
 public Fruit CreateFruit() {
	/*  if(Kind.equals("A"))
		  return new Apple();
	  if(Kind.equals("B"))
		  return new Banana();
	  */return null;
 }
}
