package FactoryDemo;

public class Banana extends Fruit{
	public void eat() {
		System.out.println("eat Banana");
	}
}
