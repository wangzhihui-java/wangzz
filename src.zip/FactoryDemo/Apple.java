package FactoryDemo;

public class Apple extends Fruit{
	public void eat() {
		System.out.println("eat Apple");
	}

}
