package FactoryDemo;

public class Fruit {
public void eat() {
}
}
