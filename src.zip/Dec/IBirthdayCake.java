package Dec;

public interface IBirthdayCake {

    public void Show();

}
