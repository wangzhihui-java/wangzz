package Dec;

public class Cake implements IBirthdayCake {

    public Cake(){
    	System.out.println("Cake blank was Cread");
    }

    public void Show(){
    	System.out.println("Cake Blank");
        
    }

}
