package Bui;

public class MealBuilder {
    protected Meal meal;

    public void buildFood(){
    }

    public void buildDrink(){
    }

    public Meal getMeal(){
        return null;
    }

}
