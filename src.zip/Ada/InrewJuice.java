package Ada;
import pro.Myfruit;
public interface InrewJuice {

    public String newPort(Myfruit fruit1, Myfruit fruit2);

}
