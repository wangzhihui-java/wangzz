package Ada;

public class CC {
public static void main(String[] args) {
	String a="abcd";
	String d="abcd";
	String b="ab"+"cd";
	String c="ab";
	c+="cd";
	System.out.println(a==d);
	
}
}
