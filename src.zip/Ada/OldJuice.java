package Ada;

import pro.Myfruit;
public class OldJuice {

    public String onePort(Myfruit fruit){
    	String str=fruit.Get()+"��֭��";
        return null;
    }

}
