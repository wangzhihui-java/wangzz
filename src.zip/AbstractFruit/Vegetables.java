package AbstractFruit;

public class Vegetables {

}
