package AbstractFruit;

public class Apple extends Fruit {

    public void eat(){
    }

}
