package AbstractFruit;

public class BFactory extends Factory {

    public Fruit CreateFruit(){
        return null;
    }

}
