package AbstractFruit;

public class AFactory extends Factory {

    public Fruit CreateFruit(){
        return null;
    }

}
