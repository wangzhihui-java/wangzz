package AbstractFruit;

public class cabbage extends Vegetables {

}
