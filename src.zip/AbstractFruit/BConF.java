package AbstractFruit;

public class BConF implements BFruitAndVegetables {

	@Override
	public Fruit CreateF() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Vegetables CreateV() {
		// TODO Auto-generated method stub
		return null;
	}

}
