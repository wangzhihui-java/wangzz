package AbstractFruit;

public class Factory {

    public Fruit CreateFruit(){
        return null;
    }

}
