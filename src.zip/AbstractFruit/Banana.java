package AbstractFruit;

public class Banana extends Fruit {

    public void eat(){
    }

}
