package AbstractFruit;

public class AConF implements AFruitAndVegetables {

	@Override
	public Fruit CreateF() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Vegetables CreateV() {
		// TODO Auto-generated method stub
		return null;
	}

}
