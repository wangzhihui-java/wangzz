package AbstractFruit;

public class Fruit {

    public void eat(){
    }

}
