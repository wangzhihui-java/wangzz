package AbstractFruit;

public interface AFruitAndVegetables {

    public Fruit CreateF();

    public Vegetables CreateV();

}
