package AbstractFruit;

public interface BFruitAndVegetables {

    public Fruit CreateF();

    public Vegetables CreateV();

}
