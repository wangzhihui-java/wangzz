package AbstractFruit;

public class tomato extends Vegetables {

}
