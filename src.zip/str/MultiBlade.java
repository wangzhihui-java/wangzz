package str;

public class MultiBlade implements ICutFruit {

    public void CutStrategy(String fruitname)
    {
    	System.out.println(fruitname+"һ���гɰ˿�");
    }

}
