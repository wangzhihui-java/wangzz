package str;

public class HoriBlade implements ICutFruit {

    public void CutStrategy(String fruitname)
    {
    	System.out.println(fruitname+"һ�α��гɼ���");
    }

}
