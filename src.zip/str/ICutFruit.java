package str;

public interface ICutFruit {

    public void CutStrategy(String fruitname);

}
