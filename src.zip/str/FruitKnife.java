package str;

public class FruitKnife implements ICutFruit {

    public void CutStrategy(String fruitname){
    }

}
