package comand;

public interface Command {
void execute();
}
