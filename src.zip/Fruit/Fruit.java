package Fruit;

public class Fruit {

    public void eat(){
    }

}
