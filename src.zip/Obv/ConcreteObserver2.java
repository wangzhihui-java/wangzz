package Obv;

public class ConcreteObserver2 implements ObserverO{

	public void response() {
		// TODO Auto-generated method stub
		System.out.println("Ŀ��仯��,2�ķ�Ӧ");
	}
	

}
