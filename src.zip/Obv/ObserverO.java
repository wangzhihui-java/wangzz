package Obv;

public interface ObserverO {

	void response();

}
