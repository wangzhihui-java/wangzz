package Obv;

public class ConcreteObserver1 implements ObserverO{

	public void response() {
		// TODO Auto-generated method stub
		System.out.println("Ŀ��仯��,1�ķ�Ӧ");
	}
	

}
