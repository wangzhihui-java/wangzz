package Ite;

public interface Televison {

}
