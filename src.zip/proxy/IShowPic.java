package proxy;

public interface IShowPic {
void ShowPic(String picname);
}
