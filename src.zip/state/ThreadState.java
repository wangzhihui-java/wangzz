package state;

public abstract class ThreadState {
 protected int state;//״̬��
}
