package state;

public class RunnableState extends ThreadState {
public RunnableState()
{
state=StateSet.RANNABLE;
System.out.println("����״̬");
}
public void getCpu(ThreadContext tc)
{
System.out.println("���CPUʱ��");	
if(state==StateSet.RANNABLE)
	tc.setThreadState(new RunningState());
else
	System.out.println("��ǰ״̬���Ǿ���״̬");
}
public void start(ThreadContext threadContext) {
	// TODO Auto-generated method stub
	
}
}
