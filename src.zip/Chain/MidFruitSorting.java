package Chain;

public class MidFruitSorting extends AbstractFruitSort {

	

	public MidFruitSorting(int weight) {
		super(weight);
		// TODO Auto-generated constructor stub
	}

	protected void pushBox(String fruit) {
		// TODO Auto-generated method stub
		  fruitBox.add("ˮ����ͷ:"+fruit);
	}

}
