package Int;

public interface Expression {
public boolean interpret(String context);
}
